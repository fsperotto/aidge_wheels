from pathlib import Path
from typing import Any

import aidge_core
import numpy as np
from aidge_core.export_utils import ExportNode, ExportNodeCpp, generate_file

from aidge_export_acetone import ExportLibAcetone
from aidge_export_acetone.export_registry import ExportNodeAcetone
from aidge_export_acetone.utils import ROOT
from aidge_export_acetone.utils.converter import numpy_dtype2ctype


def export_params(name: str, array: np.ndarray, filepath: str) -> None:

    # Get directory name of the file
    dirname = Path(filepath).parent

    # If directory doesn't exist, create it
    if not dirname.exists():
        dirname.mkdir(parents=True)

    generate_file(
        filepath,
        str(ROOT / "templates" / "data" / "parameters.jinja"),
        name=name,
        data_t=numpy_dtype2ctype(array.dtype),
        values=array.tolist(),
    )


@ExportLibAcetone.register(
    "Producer",
    aidge_core.ImplSpec(aidge_core.IOSpec(aidge_core.dtype.any)),
)
class ProducerCPP(ExportNode):
    def __init__(
        self,
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.values = np.array(self.operator.get_output(0))

        if len(self.values.shape) == 4:  # Note: export in HWC
            self.values = np.transpose(self.values, (0, 2, 3, 1))

    def export(self, export_folder: Path) -> list[str]:
        header_path = f"include/parameters/{self.attributes['name']}.h"
        export_params(
            self.attributes["out_name"][0],
            self.values.reshape(-1),
            str(export_folder / header_path),
        )
        return [header_path]

    def forward(self) -> list[str]:
        # A Producer does nothing during forward
        return []


# NOTE: FC <=> Dense
@ExportLibAcetone.register(
    "FC",
    aidge_core.ImplSpec(aidge_core.IOSpec(aidge_core.dtype.float32)),
)
class FcCPP(ExportNodeAcetone):
    forward_template = ROOT / "templates" / "kernel_forward" / "fullyconnected_forward.jinja"
    include_list: list[str] = []


@ExportLibAcetone.register(
    "Add",
    aidge_core.ImplSpec(aidge_core.IOSpec(aidge_core.dtype.float32)),
)
class AddCPP(ExportNodeAcetone):
    forward_template = ROOT / "templates" / "kernel_forward" / "add_forward.jinja"
    include_list: list[str] = ["stddef.h"]


@ExportLibAcetone.register(
    "MatMul",
    aidge_core.ImplSpec(aidge_core.IOSpec(aidge_core.dtype.float32)),
)
class MatMulCPP(ExportNodeAcetone):
    forward_template = ROOT / "templates" / "kernel_forward" / "matmul_forward.jinja"
    include_list: list[str] = ["stddef.h"]


@ExportLibAcetone.register(
    "ReLU",
    aidge_core.ImplSpec(aidge_core.IOSpec(aidge_core.dtype.float32)),
)
class ReluCPP(ExportNodeAcetone):
    forward_template = ROOT / "templates" / "kernel_forward" / "relu_forward.jinja"
    include_list: list[str] = ["stddef.h"]


@ExportLibAcetone.register(
    "Conv2D",
    aidge_core.ImplSpec(aidge_core.IOSpec(aidge_core.dtype.float32)),
)
class Conv2d(ExportNodeAcetone):
    forward_template = ROOT / "templates" / "kernel_forward" / "conv2d.jinja"
    include_list: list[str] = ["stddef.h"]
