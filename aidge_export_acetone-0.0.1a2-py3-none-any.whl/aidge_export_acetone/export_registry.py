from pathlib import Path

from aidge_core.export_utils import ExportLib, ExportNode, code_generation

from aidge_export_acetone.utils import ROOT


class ExportNodeAcetone(ExportNode):
    """Base node exporter class for the ACETONE backend."""

    include_list: list[str]
    forward_template: str | Path

    def __init__(self, *args, **kwargs) -> None:
        """Initialise node attributes for export."""
        super().__init__(*args, **kwargs)
        # Broadcast input array dimensions onto outputs for each (input, output) pair
        self.attributes["in_bdims"] = [
            [None] * self.attributes["nb_out"] for _ in range(self.attributes["nb_in"])
        ]
        for i, d in enumerate(self.attributes["in_dims"]):
            for j, b in enumerate(self.attributes["out_dims"]):
                self.attributes["in_bdims"][i][j] = self.broadcast_dims(d, b)

    @staticmethod
    def broadcast_dims(
        dims: list[int],
        bdims: list[int],
        *,
        bvalue: int = 1,
        append: bool = False,
    ) -> list[int]:
        """Broadcast a dimension array to match target array dimensions.

        TODO Ensure the output array has the same length as bdims
        TODO Ensure all values in dims are in the output
            (either at the start (append=True), or beginning (append=False))
        TODO Ensure all added values in the output are the pad value (bvalue)
        """
        pad = [bvalue] * (len(bdims) - len(dims))
        return dims + pad if append else pad + dims

    def export(self, _: str) -> list[str]:
        """Define how to export the node implementation.

        Create required files for the forward implementation of the node in C. This may
        include supporting computation kernels, functions, or data allocation.

        Returns a list of includes required to define the node inference.
        """
        return self.include_list if self.include_list is not None else []

    def forward(self) -> list[str]:
        """Generate a string with the forward implementation in C for the node.

        The implementation must read from the allocated variable for each input.
        The implementation must write to the allocated variable for each output.
        All intermediate variables are named as to reduce the likelihood of
        conflicts.
        The generated code must be properly scoped.

        See aidge_core.export_utils.scheduler_export for more information on the
        generated execution code context.

        See aidge_core.export_utils.node_export.ExportNode for more information on
        available attributes on the node and input/output tensors.
        """
        if self.forward_template is None:
            msg = "forward_template have not been defined"
            raise ValueError(msg)
        forward_call: str = code_generation.generate_str(
            self.forward_template, **self.attributes
        )
        return [forward_call]


class ExportLibAcetone(ExportLib):
    """ACETONE Export backend."""

    _name = "export_acetone"
    static_files = {
        str(ROOT / "static" / "Makefile"): "",
    }
