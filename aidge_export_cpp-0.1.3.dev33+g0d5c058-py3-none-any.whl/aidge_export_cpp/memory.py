import aidge_core
import aidge_backend_cpu
from typing import List

# for each layer, name: [size, offset start]
# Example:
#define ENV_MEM_SIZE 3
#define ENV_OFFSET 0
MEMORY_INFO_TEMPLATE = ["layer_name", "size", "offset"]


# Default memory management, which can be used for development
def compute_default_mem_info(scheduler: aidge_core.Scheduler):
    
    list_forward_nodes = scheduler.get_static_scheduling()
    mem_info = []
    mem_size = 0

    # Exclude Producers and the last layers (because the results are stored outside the export)
    for i, node in enumerate(list_forward_nodes):
        if node.type() != "Producer":
            if len(node.get_children()) != 0:
                dims = node.get_operator().get_output(0).dims()
                mem = 1
                for dim in dims:
                    mem *= dim

                # Add memeory info
                mem_info.append([node.name(), mem, mem_size])
                
                # Increment offset for the next layer
                mem_size += mem

    return mem_size, mem_info


def generate_optimized_memory_info(scheduler: aidge_core.Scheduler,
                                   wrapping:bool = False):
    
    # The forward dims has to done outside the function

    # Generate the memory manager
    mem_manager = scheduler.generate_memory(inc_producers=False, wrap_around_buffer=wrapping)

    mem_size = 0
    mem_info = []


    return mem_size, mem_info