from aidge_core.export_utils import ExportLib
from . import ROOT_EXPORT
import aidge_core


class ExportSerialize(ExportLib):
    _name="export_serialize"
